package com.cg.rms.ui;

public interface CompanyUI {
	public void regCompDetails();
	public void postJobReq() ;
	public void searchCandidate();
	  public String showCompanyMenu(String id);
}
