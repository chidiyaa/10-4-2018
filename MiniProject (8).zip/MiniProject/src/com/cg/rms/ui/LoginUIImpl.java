package com.cg.rms.ui;

import java.text.ParseException;
import java.util.Scanner;

import com.cg.rms.beans.User;
import com.cg.rms.exception.RecruitmentException;
import com.cg.rms.service.CandidateServiceImpl;
import com.cg.rms.service.CompanyServiceImpl;
import com.cg.rms.service.LoginService;
import com.cg.rms.service.LoginServiceImpl;
import com.cg.rms.service.PlacedCandidateServiceImpl;

public class LoginUIImpl implements LoginUI {

	Scanner sc = new Scanner(System.in);
	static int loginAttempt=3;
	LoginService loginService=new LoginServiceImpl();//need to change to interface
	CandidateUIImpl candidateUI=new CandidateUIImpl();//need to change to interface
	AdminUIImpl adminUI=new AdminUIImpl();//need to change to interface
	CompanyUIImpl companyUI=new CompanyUIImpl();//need to change to interface


	@Override
	public void login() throws ParseException {


		System.out.println("-------Login Here------");
		System.out.println("Enter userID");
		String userName = sc.next();
		System.out.println("Enter Password");
		String password = sc.next();	
		try {
			User user = loginService.login(userName, password);//    Service Layer Call
			if(user==null)
			{
				System.out.println("ID Password Does Not Match");
				loginAttempt--;
				if(loginAttempt > 0)
				{
					System.out.println("You Have "+loginAttempt+" Login Attempts Left");
					login();//stack
				}
				else
				{
					System.out.println("You Are Being Taken Back To Main Menu");
					loginAttempt=3;
					showMenu();
				}
			}
			else
			{
				System.out.println("Successfully Logged In");   // to be removed
				if(user.getTypeUser().equals("candidate"))
				{
					System.out.println("candidateUI.showCandidateMenu(user.getId())");
					int ch=sc.nextInt();
					switch(ch){
					
					case 1:candidateUI.addResume();break;
					case 2:candidateUI.modifyResume();break;
					case 3:candidateUI.applyJobs();break;
					case 4:candidateUI.searchJobs();break;
				default:System.out.println("Invalid choice");

					}
				}
				else if(user.getTypeUser().equals("company"))
				{
					companyUI.showCompanyMenu(user.getId());
				}
				else
				{
					adminUI.showAdminMenu(user.getId());
				}
			}


		}

		catch (RecruitmentException e) {
			e.printStackTrace();
		}




	}

	@Override
	public void showMenu() throws ParseException {
		// TODO Auto-generated method stub

		System.out.println("Welcome To Recruitment  Management System");
		System.out.println("Please Choose Any Option");
		System.out.println("1. Login");
		System.out.println("2. Signup");
		System.out.println("3. Exit");
		int choice = sc.nextInt();
		switch(choice)
		{
		case 1:
			login();
			break;
		case 2:
			signUp();
			break;
		case 3:
			System.out.println("You Selected Exit, Program Will Terminate Bye");
			System.exit(0);
			break;

		default:
			System.out.println("Invalid Choice! Please Try Again");
			break;
		}






	}

	@Override
	public void signUp()  {
		System.out.println("-----Sign Up here-----");
		System.out.println("User Name");
		String userName=sc.next();
		System.out.println("Enter Password ");
		String password=sc.next();
		System.out.println("Enter User Type ");
		String userType=sc.next();
		try
		{
			User user=new User(userName,password,userType,"");
			String userId=loginService.signUp(user);
			User user1=loginService.login(userName, password);
			System.out.println("You have successfully Registered and your ID is "+userId);
			if(user.getTypeUser().equals("candidate"))
			{
				System.out.println(candidateUI.showCandidateMenu(user1.getId()));
				
				int choice=0;
				choice=sc.nextInt();
				CandidateServiceImpl candidateService=new CandidateServiceImpl();
				try {
					switch(choice)
					{
					case 1:candidateUI.addResume();break;
					case 2:candidateUI.modifyResume();break;
					case 3:candidateUI.searchJobs();break;
					case 4:candidateUI.applyJobs();break;
					case 5:System.exit(0); break;
					default:System.out.println("Invalid input");
					}
				}
				catch (ParseException e) {

					e.printStackTrace();
				}


			}
			else if(user.getTypeUser().equals("company"))
			{
				System.out.println(companyUI.showCompanyMenu(user1.getId()));
				int choice=0;
				choice=sc.nextInt();
				CompanyServiceImpl companyService=new CompanyServiceImpl();
				switch(choice)
				{
				case 1:companyUI.regCompDetails();break;
				case 2:companyUI.postJobReq();break;
				case 3:companyUI.searchCandidate();;break;
				case 4:System.exit(0); break;
				default:System.out.println("Invalid input");
				}
			}
			else
			{
				System.out.println(adminUI.showAdminMenu(user1.getId()));
				int choice=0;
				choice=sc.nextInt();
				PlacedCandidateServiceImpl placedcandidateService=new PlacedCandidateServiceImpl();
				switch(choice)
				{
				case 1: System.out.println("Enter month");
				String month =sc.next();
				placedcandidateService.pCountMonth(month);break;
				case 2: System.out.println("Enter company");
				String Company =sc.next();
				placedcandidateService.pCountCompany(Company);break;
				case 3:System.out.println("Enter designation");
				String designation =sc.next();
					placedcandidateService.pCountDesignation(designation);break;
				case 4:System.exit(0); break;
				default:System.out.println("Invalid input");
				}
			}
		}
		catch(RecruitmentException e)
		{
			e.printStackTrace();
		}

	}
	public static void main(String args[]) throws ParseException{
		LoginUIImpl lgi=new LoginUIImpl();
		lgi.showMenu();
	}

}
