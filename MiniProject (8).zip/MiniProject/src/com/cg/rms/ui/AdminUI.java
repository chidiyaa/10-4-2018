package com.cg.rms.ui;

public interface AdminUI {
    public String showAdminMenu(String id);
	void countpcmonth(String month);
	void countpccompany(String Company);
	void countpcposition(String designation);
}
